/**
 * Scribd Downloader Pro v3.0.0 — Ultra-Fast Direct CDN & Turbo PDF Engine
 */
(function () {
  'use strict';

  var CFG = window.SDP_CONFIG || {
    ajaxUrl: '/wp-admin/admin-ajax.php',
    antiBlockMode: 'hybrid-auto',
    remoteApiUrl: '',
    remoteApiKey: '',
    pdfPageSize: 'A4',
    fetchBtnText: 'Fetch Document',
    downloadBtnText: 'Download PDF',
    fetchBtnAdUrl: '',
    downloadBtnAdUrl: '',
    downloadCountdownSec: 0
  };

  var DOC_MEMORY_CACHE = {};

  function extractScribdId(input) {
    if (!input) return null;
    var trimmed = String(input).trim();
    if (/^\d{5,14}$/.test(trimmed)) return trimmed;
    var m = trimmed.match(/(?:scribd\.com\/(?:doc|document|presentation|embeds|read|book|audiobook)\/|\b)(\d{6,14})\b/i);
    return m ? m[1] : null;
  }

  function normalizeHttpsAsset(url) {
    if (!url) return url;
    return url
      .replace(/^\\\//g, '/')
      .replace(/^\/\//, 'https://')
      .replace(/^http:\/\/html\.scribd\.com\//i, 'https://html.scribdassets.com/')
      .replace(/^https:\/\/html\.scribd\.com\//i, 'https://html.scribdassets.com/')
      .replace(/^http:\/\//i, 'https://');
  }

  function buildGoogleTranslateEdgeUrl(rawUrl) {
    try {
      var u = new URL(rawUrl);
      var translatedHost = u.hostname.replace(/\./g, '-') + '.translate.goog';
      var sep = u.search ? '&' : '?';
      return 'https://' + translatedHost + u.pathname + u.search + sep + '_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en&_x_tr_pto=wapp';
    } catch (e) {
      return rawUrl;
    }
  }

  // Ultra-fast direct + multi-edge fetch for JSONP & HTML
  async function fetchTextUltraFast(targetUrl, timeoutMs) {
    timeoutMs = timeoutMs || 3200;
    var normalized = normalizeHttpsAsset(targetUrl);

    // FAST PATH 1: html*.scribdassets.com supports direct browser CORS in ~35ms!
    if (normalized.indexOf('scribdassets.com') !== -1) {
      try {
        var directCtrl = new AbortController();
        var directTimer = setTimeout(function () { directCtrl.abort(); }, 1800);
        var directRes = await fetch(normalized, { signal: directCtrl.signal });
        clearTimeout(directTimer);
        if (directRes.ok) {
          var directText = await directRes.text();
          if (directText && directText.length > 30) {
            return directText;
          }
        }
      } catch (e) {
        // Fall through to parallel relays
      }
    }

    var gEdge = normalized.indexOf('scribd.com') !== -1 ? buildGoogleTranslateEdgeUrl(normalized) : normalized;

    var candidates = [
      CFG.ajaxUrl + '?action=sdp_proxy_asset&url=' + encodeURIComponent(normalized),
      'https://corsproxy.io/?' + encodeURIComponent(normalized),
      'https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(normalized)
    ];

    if (gEdge !== normalized) {
      candidates.push('https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(gEdge));
    }

    return new Promise(function (resolve) {
      var settled = false;
      var pending = candidates.length;
      var controllers = [];

      candidates.forEach(function (proxyUrl) {
        var ctrl = new AbortController();
        controllers.push(ctrl);
        var timer = setTimeout(function () { ctrl.abort(); }, timeoutMs);

        fetch(proxyUrl, { signal: ctrl.signal })
          .then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.text();
          })
          .then(function (text) {
            clearTimeout(timer);
            if (settled) return;
            if (!text || text.length < 25 || text.indexOf('<title>Client Challenge</title>') !== -1) {
              throw new Error('Challenge');
            }
            settled = true;
            controllers.forEach(function (c) {
              try { c.abort(); } catch (err) {}
            });
            resolve(text);
          })
          .catch(function () {
            clearTimeout(timer);
            pending--;
            if (pending <= 0 && !settled) {
              resolve(null);
            }
          });
      });
    });
  }

  function parseJsonpPageContent(rawJsonp, assetPrefix) {
    var unescaped = String(rawJsonp || '')
      .replace(/\\"/g, '"')
      .replace(/\\n/g, '\n')
      .replace(/\\t/g, ' ')
      .replace(/\\\//g, '/');

    var imgSet = {};
    var absMatches = unescaped.match(/https?:\/\/[^"'\s<>()\\]+\.(?:scribdassets\.com|scribd\.com)\/[^"'\s<>()\\]+\/images\/\d+-[a-zA-Z0-9]+\.(?:jpg|jpeg|png)/gi) || [];
    absMatches.forEach(function (u) {
      imgSet[normalizeHttpsAsset(u)] = true;
    });

    var origMatches = unescaped.match(/(?:orig|src)\s*=\s*["']([^"']+\.(?:jpg|jpeg|png)[^"']*)["']/gi) || [];
    origMatches.forEach(function (m) {
      var inner = m.match(/["']([^"']+)["']/);
      if (inner && inner[1]) {
        var src = inner[1].trim();
        if (/spacer|blank|empty|1x1|transparent/i.test(src)) return;
        if (/^https?:\/\//i.test(src) || /^\/\//.test(src)) {
          imgSet[normalizeHttpsAsset(src)] = true;
        } else if (assetPrefix) {
          var cp = normalizeHttpsAsset(assetPrefix.replace(/\/$/, ''));
          var cr = src.replace(/^\/+/, '').replace(/^images\//i, '');
          imgSet[cp + '/images/' + cr] = true;
        }
      }
    });

    if (Object.keys(imgSet).length === 0 && assetPrefix) {
      var cleanPrefix = normalizeHttpsAsset(assetPrefix.replace(/\/$/, ''));
      var relMatches = unescaped.match(/(?:images\/)?\d+-[a-zA-Z0-9]+\.(?:jpg|jpeg|png)/gi) || [];
      relMatches.forEach(function (rel) {
        var cleanRel = rel.replace(/^images\//i, '');
        imgSet[cleanPrefix + '/images/' + cleanRel] = true;
      });
    }

    var plainText = unescaped
      .replace(/^.*?window\.page_loader\.\_\_jsonp\_callback\s*\(\s*\d+\s*,\s*\[/s, '')
      .replace(/\]\s*\)\s*;?\s*$/s, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/\s+/g, ' ')
      .trim();

    return {
      imageUrls: Object.keys(imgSet),
      text: plainText
    };
  }

  function parseEmbedHtmlForPages(rawHtml, docId) {
    var html = String(rawHtml || '')
      .replace(/\\\//g, '/')
      .replace(/\\u0026/g, '&')
      .replace(/\\"/g, '"');

    var title = 'Scribd Document #' + docId;
    var titleMatch = html.match(/<title>([^<]+)<\/title>/i) || html.match(/"title"\s*:\s*"([^"]+)"/i);
    if (titleMatch && titleMatch[1]) {
      var cleanT = titleMatch[1].replace(/\s*[-|]\s*Scribd.*$/i, '').trim();
      if (cleanT && cleanT.toLowerCase() !== 'scribd' && cleanT !== 'Client Challenge') {
        title = cleanT;
      }
    }

    var prefixMatch =
      html.match(/asset_prefix\s*[:=]\s*["'](https?:\/\/[^"']+?)["']/i) ||
      html.match(/(https?:\/\/(?:html[0-9a-z-]*\.scribdassets\.com|html\.scribd\.com)\/[a-zA-Z0-9_-]+\/)/i);
    var assetPrefix = prefixMatch ? normalizeHttpsAsset(prefixMatch[1]) : '';

    var pageMap = {};

    // 1. Full Image URLs across all scribdassets.com subdomains (html, html1-f, html2-f, etc.)
    var imgMatches = html.match(/https?:\/\/[^"'\s<>()\\]+\.(?:scribdassets\.com|scribd\.com)\/[^"'\s<>()\\]+\/images\/\d+-[a-zA-Z0-9]+\.(?:jpg|jpeg|png)/gi) || [];
    imgMatches.forEach(function (raw) {
      var clean = normalizeHttpsAsset(raw);
      var pm = clean.match(/\/images\/(\d+)-[a-zA-Z0-9]+\.(?:jpg|jpeg|png)/i);
      var pnum = pm ? parseInt(pm[1], 10) : 1;
      if (!pageMap[pnum]) pageMap[pnum] = { pageNumber: pnum, imageUrl: clean, jsonpUrl: null, text: '' };
      else pageMap[pnum].imageUrl = clean;
    });

    // 2. Full JSONP URLs across all scribdassets.com subdomains
    var jpMatches = html.match(/https?:\/\/[^"'\s<>()\\]+\.(?:scribdassets\.com|scribd\.com)\/[^"'\s<>()\\]+\/pages\/\d+-[a-zA-Z0-9]+\.jsonp/gi) || [];
    jpMatches.forEach(function (raw) {
      var clean = normalizeHttpsAsset(raw);
      var pm = clean.match(/\/pages\/(\d+)-[a-zA-Z0-9]+\.jsonp/i);
      var pnum = pm ? parseInt(pm[1], 10) : 1;
      if (!pageMap[pnum]) pageMap[pnum] = { pageNumber: pnum, imageUrl: null, jsonpUrl: clean, text: '' };
      else pageMap[pnum].jsonpUrl = clean;
    });

    // 3. Relative paths when assetPrefix is present
    if (assetPrefix) {
      var base = assetPrefix.replace(/\/$/, '');
      var relJp = html.match(/\/?pages\/(\d+)-([a-zA-Z0-9]+)\.jsonp/gi) || [];
      relJp.forEach(function (r) {
        var m = r.match(/(\d+)-([a-zA-Z0-9]+)\.jsonp/i);
        if (m) {
          var pnum = parseInt(m[1], 10);
          var fullJp = base + '/pages/' + pnum + '-' + m[2] + '.jsonp';
          if (!pageMap[pnum]) pageMap[pnum] = { pageNumber: pnum, imageUrl: null, jsonpUrl: fullJp, text: '' };
          else if (!pageMap[pnum].jsonpUrl) pageMap[pnum].jsonpUrl = fullJp;
        }
      });

      var relImg = html.match(/\/?images\/(\d+)-([a-zA-Z0-9]+)\.(jpg|jpeg|png)/gi) || [];
      relImg.forEach(function (r) {
        var m = r.match(/(\d+)-([a-zA-Z0-9]+)\.(jpg|jpeg|png)/i);
        if (m) {
          var pnum = parseInt(m[1], 10);
          var fullImg = base + '/images/' + pnum + '-' + m[2] + '.' + m[3];
          if (!pageMap[pnum]) pageMap[pnum] = { pageNumber: pnum, imageUrl: fullImg, jsonpUrl: null, text: '' };
          else if (!pageMap[pnum].imageUrl) pageMap[pnum].imageUrl = fullImg;
        }
      });
    }

    var sortedNums = Object.keys(pageMap).map(Number).sort(function (a, b) { return a - b; });
    var pages = sortedNums.map(function (n) { return pageMap[n]; });

    return {
      id: docId,
      title: title,
      pageCount: pages.length,
      embedUrl: 'https://www.scribd.com/embeds/' + docId + '/content?start_page=1&view_mode=scroll&access_key=key-fFexxf7r1bzEfWu3HKwf',
      assetPrefix: assetPrefix,
      pages: pages
    };
  }

  // PARALLEL ULTRA-FAST RACE: WordPress Server WhatsApp-UA Direct (~174ms) + Browser Edge run simultaneously!
  async function resolveRealScribdDocument(rawUrl) {
    var docId = extractScribdId(rawUrl);
    if (!docId) {
      throw new Error('Invalid Scribd URL. Please paste a valid link like https://www.scribd.com/document/991278283/...');
    }

    if (DOC_MEMORY_CACHE[docId]) {
      return DOC_MEMORY_CACHE[docId];
    }

    var embedUrl = 'https://www.scribd.com/embeds/' + docId + '/content?start_page=1&view_mode=scroll&access_key=key-fFexxf7r1bzEfWu3HKwf';
    var tasks = [];

    // Channel A: WordPress AJAX Server Direct WhatsApp-UA Extraction (~180ms)
    if (CFG.antiBlockMode !== 'browser-edge') {
      tasks.push(
        (async function () {
          var formData = new URLSearchParams();
          formData.append('action', 'sdp_resolve_document');
          formData.append('url', rawUrl);
          var res = await fetch(CFG.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData.toString()
          });
          var data = await res.json();
          if (data && data.success && data.data && data.data.pages && data.data.pages.length > 0) {
            return data.data;
          }
          throw new Error('Server empty');
        })()
      );
    }

    // Channel B: Browser Direct Edge Race
    if (CFG.antiBlockMode !== 'server-edge') {
      tasks.push(
        (async function () {
          var edgeHtml = await fetchTextUltraFast(embedUrl, 3800);
          if (edgeHtml && edgeHtml.length > 500) {
            var parsed = parseEmbedHtmlForPages(edgeHtml, docId);
            if (parsed.pages && parsed.pages.length > 0) {
              return parsed;
            }
          }
          throw new Error('Browser relay empty');
        })()
      );
    }

    return new Promise(function (resolve, reject) {
      var settled = false;
      var failed = 0;
      tasks.forEach(function (p) {
        p.then(function (doc) {
          if (!settled && doc && doc.pages && doc.pages.length > 0) {
            settled = true;
            resolve(doc);
          }
        }).catch(function () {
          failed++;
          if (failed >= tasks.length && !settled) {
            reject(new Error('Could not extract pages for Document #' + docId + '. Please verify the Scribd document link is public.'));
          }
        });
      });
    });
  }

  function fetchImageAsDataUrl(imageUrl) {
    var candidates = [
      'https://wsrv.nl/?url=' + encodeURIComponent(imageUrl) + '&output=jpg',
      'https://wsrv.nl/?url=' + encodeURIComponent(imageUrl) + '&w=1400&output=jpg',
      CFG.ajaxUrl + '?action=sdp_proxy_asset&url=' + encodeURIComponent(imageUrl)
    ];

    return new Promise(function (resolve) {
      var idx = 0;
      function tryNext() {
        if (idx >= candidates.length) {
          resolve(null);
          return;
        }
        var currentUrl = candidates[idx++];
        fetch(currentUrl)
          .then(function (r) {
            if (!r.ok) throw new Error('Status ' + r.status);
            return r.blob();
          })
          .then(function (blob) {
            if (!blob || blob.size < 400) throw new Error('Empty image');
            var reader = new FileReader();
            reader.onloadend = function () { resolve(reader.result); };
            reader.onerror = function () { tryNext(); };
            reader.readAsDataURL(blob);
          })
          .catch(function () {
            tryNext();
          });
      }
      tryNext();
    });
  }

  function triggerAdUrlIfConfigured(adUrl) {
    if (!adUrl || typeof adUrl !== 'string' || !adUrl.trim()) return;
    try {
      window.open(adUrl.trim(), '_blank', 'noopener,noreferrer');
    } catch (e) {}
  }

  function initWidget(wrapper) {
    var form = wrapper.querySelector('.sdp-form');
    var urlInput = wrapper.querySelector('.sdp-url-input');
    var fetchBtn = wrapper.querySelector('.sdp-fetch-btn');
    var fetchSpinner = wrapper.querySelector('.sdp-fetch-spinner');
    var fetchIcon = wrapper.querySelector('.sdp-fetch-icon');
    var fetchBtnLabel = wrapper.querySelector('.sdp-fetch-btn-label');
    var errorBox = wrapper.querySelector('.sdp-error-box');
    var progressPanel = wrapper.querySelector('.sdp-progress-panel');
    var statusSpinner = wrapper.querySelector('.sdp-status-spinner');
    var statusCheck = wrapper.querySelector('.sdp-status-check');
    var statusText = wrapper.querySelector('.sdp-status-text');
    var pageCountBadge = wrapper.querySelector('.sdp-page-count-badge');
    var progressBarFill = wrapper.querySelector('.sdp-progress-bar-fill');

    var resultContainer = wrapper.querySelector('.sdp-result-container');
    var detectedPagesLabel = wrapper.querySelector('.sdp-detected-pages-label');
    var docIdLabel = wrapper.querySelector('.sdp-doc-id-label');
    var docTitleEl = wrapper.querySelector('.sdp-doc-title');
    var downloadPdfBtn = wrapper.querySelector('.sdp-download-pdf-btn');
    var downloadSpinner = wrapper.querySelector('.sdp-download-spinner');
    var downloadIcon = wrapper.querySelector('.sdp-download-icon');
    var downloadBtnLabel = wrapper.querySelector('.sdp-download-btn-label');

    var tabBtns = wrapper.querySelectorAll('.sdp-tab-btn');
    var paneSlider = wrapper.querySelector('.sdp-pane-slider');
    var paneEmbed = wrapper.querySelector('.sdp-pane-embed');
    var paneGrid = wrapper.querySelector('.sdp-pane-grid');

    var prevPageBtn = wrapper.querySelector('.sdp-prev-page');
    var nextPageBtn = wrapper.querySelector('.sdp-next-page');
    var sliderIndicator = wrapper.querySelector('.sdp-slider-indicator');
    var pageRange = wrapper.querySelector('.sdp-page-range');
    var slideImg = wrapper.querySelector('.sdp-slide-img');
    var slideText = wrapper.querySelector('.sdp-slide-text');
    var thumbsStrip = wrapper.querySelector('.sdp-thumbs-strip');
    var embedIframe = wrapper.querySelector('.sdp-embed-iframe');
    var pagesGridList = wrapper.querySelector('.sdp-pages-grid-list');

    var currentDoc = null;
    var activePage = 1;
    var isBusy = false;

    function setFetchLoadingState(loading, labelText) {
      fetchBtn.disabled = loading;
      if (fetchSpinner) fetchSpinner.style.display = loading ? 'inline-block' : 'none';
      if (fetchIcon) fetchIcon.style.display = loading ? 'none' : 'inline-block';
      fetchBtnLabel.textContent = labelText || (loading ? 'Fetching...' : CFG.fetchBtnText);
    }

    function setDownloadLoadingState(loading, labelText) {
      downloadPdfBtn.disabled = loading;
      if (downloadSpinner) downloadSpinner.style.display = loading ? 'inline-block' : 'none';
      if (downloadIcon) downloadIcon.style.display = loading ? 'none' : 'inline-block';
      downloadBtnLabel.textContent = labelText || CFG.downloadBtnText;
    }

    function setProgressStatus(isSpinning, message) {
      if (statusSpinner) statusSpinner.style.display = isSpinning ? 'inline-block' : 'none';
      if (statusCheck) statusCheck.style.display = isSpinning ? 'none' : 'inline-flex';
      statusText.textContent = message;
    }

    function showError(msg) {
      if (!msg) {
        errorBox.style.display = 'none';
        errorBox.textContent = '';
      } else {
        errorBox.style.display = 'block';
        errorBox.textContent = msg;
      }
    }

    async function resolveSinglePageIfNeeded(pageObj, assetPrefix) {
      if (!pageObj || pageObj.imageUrl || !pageObj.jsonpUrl) return;
      var rawJp = await fetchTextUltraFast(pageObj.jsonpUrl, 2500);
      if (rawJp) {
        var parsedJp = parseJsonpPageContent(rawJp, assetPrefix);
        if (parsedJp.imageUrls && parsedJp.imageUrls.length > 0) {
          pageObj.imageUrl = parsedJp.imageUrls[0];
        }
        if (parsedJp.text) {
          pageObj.text = parsedJp.text;
        }
      }
    }

    function renderActiveSlide() {
      if (!currentDoc || !currentDoc.pages.length) return;
      var total = currentDoc.pages.length;
      if (activePage < 1) activePage = 1;
      if (activePage > total) activePage = total;

      var pageObj = currentDoc.pages[activePage - 1];
      sliderIndicator.textContent = 'Page ' + activePage + ' of ' + total;
      pageRange.max = String(total);
      pageRange.value = String(activePage);
      prevPageBtn.disabled = activePage <= 1;
      nextPageBtn.disabled = activePage >= total;

      if (pageObj && pageObj.imageUrl) {
        slideImg.style.display = 'block';
        slideImg.src = 'https://wsrv.nl/?url=' + encodeURIComponent(pageObj.imageUrl) + '&output=jpg';
        slideText.style.display = 'none';
      } else if (pageObj && pageObj.jsonpUrl) {
        slideImg.style.display = 'none';
        slideText.style.display = 'block';
        slideText.textContent = 'Loading Page ' + activePage + ' preview...';
        resolveSinglePageIfNeeded(pageObj, currentDoc.assetPrefix).then(function () {
          if (currentDoc && activePage === pageObj.pageNumber) {
            renderActiveSlide();
          }
        });
      } else {
        slideImg.style.display = 'none';
        slideText.style.display = 'block';
        slideText.textContent = (pageObj && pageObj.text) ? pageObj.text : ('Page ' + activePage + ' ready.');
      }

      var thumbBtns = thumbsStrip.querySelectorAll('.sdp-thumb-item');
      thumbBtns.forEach(function (b, idx) {
        if (idx + 1 === activePage) b.classList.add('active');
        else b.classList.remove('active');
      });
    }

    function updateThumbnailAndGridDomForPage(p) {
      if (!p || !p.imageUrl) return;
      var thumbBtn = thumbsStrip.querySelector('[data-page-num="' + p.pageNumber + '"]');
      if (thumbBtn && !thumbBtn.querySelector('img')) {
        var timg = document.createElement('img');
        timg.src = 'https://wsrv.nl/?url=' + encodeURIComponent(p.imageUrl) + '&w=140&output=jpg';
        timg.loading = 'lazy';
        thumbBtn.insertBefore(timg, thumbBtn.firstChild);
      }
      var gridCard = pagesGridList.querySelector('[data-grid-page="' + p.pageNumber + '"]');
      if (gridCard && !gridCard.querySelector('img')) {
        var gimg = document.createElement('img');
        gimg.src = 'https://wsrv.nl/?url=' + encodeURIComponent(p.imageUrl) + '&output=jpg';
        gimg.loading = 'lazy';
        gridCard.appendChild(gimg);
      }
    }

    function buildThumbnailsAndGrid() {
      thumbsStrip.innerHTML = '';
      pagesGridList.innerHTML = '';
      if (!currentDoc) return;

      currentDoc.pages.forEach(function (p) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.setAttribute('data-page-num', String(p.pageNumber));
        btn.className = 'sdp-thumb-item' + (p.pageNumber === activePage ? ' active' : '');
        if (p.imageUrl) {
          var timg = document.createElement('img');
          timg.src = 'https://wsrv.nl/?url=' + encodeURIComponent(p.imageUrl) + '&w=140&output=jpg';
          timg.loading = 'lazy';
          btn.appendChild(timg);
        }
        var badge = document.createElement('span');
        badge.className = 'sdp-thumb-num';
        badge.textContent = 'P.' + p.pageNumber;
        btn.appendChild(badge);
        btn.addEventListener('click', function () {
          activePage = p.pageNumber;
          renderActiveSlide();
        });
        thumbsStrip.appendChild(btn);

        var card = document.createElement('div');
        card.className = 'sdp-grid-page-card';
        card.setAttribute('data-grid-page', String(p.pageNumber));
        var head = document.createElement('div');
        head.className = 'sdp-grid-page-head';
        head.textContent = 'PAGE ' + p.pageNumber + ' OF ' + currentDoc.pages.length;
        card.appendChild(head);

        if (p.imageUrl) {
          var gimg = document.createElement('img');
          gimg.src = 'https://wsrv.nl/?url=' + encodeURIComponent(p.imageUrl) + '&output=jpg';
          gimg.loading = 'lazy';
          card.appendChild(gimg);
        } else if (p.text) {
          var gtxt = document.createElement('div');
          gtxt.className = 'sdp-grid-page-text';
          gtxt.textContent = p.text;
          card.appendChild(gtxt);
        }
        pagesGridList.appendChild(card);
      });
    }

    tabBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        tabBtns.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        var tab = btn.getAttribute('data-tab');
        paneSlider.style.display = tab === 'slider' ? 'block' : 'none';
        paneEmbed.style.display = tab === 'embed' ? 'block' : 'none';
        paneGrid.style.display = tab === 'grid' ? 'block' : 'none';
        if (tab === 'embed' && currentDoc && embedIframe.src === 'about:blank') {
          embedIframe.src = currentDoc.embedUrl;
        }
      });
    });

    prevPageBtn.addEventListener('click', function () {
      if (activePage > 1) {
        activePage--;
        renderActiveSlide();
      }
    });

    nextPageBtn.addEventListener('click', function () {
      if (currentDoc && activePage < currentDoc.pages.length) {
        activePage++;
        renderActiveSlide();
      }
    });

    pageRange.addEventListener('input', function () {
      activePage = parseInt(pageRange.value, 10) || 1;
      renderActiveSlide();
    });

    // STEP 1 -> STEP 2: ULTRA-FAST SUB-SECOND FETCH & INSTANT PREVIEW
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      if (isBusy) return;

      var rawUrl = urlInput.value.trim();
      if (!rawUrl) {
        showError('Please paste a valid Scribd document link first.');
        return;
      }

      triggerAdUrlIfConfigured(CFG.fetchBtnAdUrl);

      isBusy = true;
      showError(null);
      resultContainer.style.display = 'none';
      progressPanel.style.display = 'block';
      progressBarFill.style.width = '25%';
      setProgressStatus(true, 'Fetching document pages...');
      pageCountBadge.textContent = 'Fetching...';
      setFetchLoadingState(true, 'Fetching...');

      try {
        var doc = await resolveRealScribdDocument(rawUrl);
        var total = doc.pages.length;

        pageCountBadge.textContent = total + ' Pages';
        setProgressStatus(true, 'Found ' + total + ' pages — opening preview...');
        progressBarFill.style.width = '65%';

        // Resolve first 4 pages in parallel (<50ms via direct scribdassets.com CORS) so Page 1 preview is instant
        var firstPages = doc.pages.slice(0, 4);
        await Promise.all(firstPages.map(function (p) {
          return resolveSinglePageIfNeeded(p, doc.assetPrefix);
        }));

        currentDoc = doc;
        DOC_MEMORY_CACHE[doc.id] = doc;
        activePage = 1;
        embedIframe.src = 'about:blank';

        detectedPagesLabel.textContent = total + ' PAGES DETECTED';
        docIdLabel.textContent = 'DOC #' + doc.id;
        docTitleEl.textContent = doc.title;
        setDownloadLoadingState(false, CFG.downloadBtnText + ' (' + total + ' Pages)');

        buildThumbnailsAndGrid();
        renderActiveSlide();
        resultContainer.style.display = 'block';

        // Unlock Fetch button immediately so user never waits!
        isBusy = false;
        setFetchLoadingState(false, CFG.fetchBtnText);
        progressBarFill.style.width = '100%';
        setProgressStatus(false, 'All ' + total + ' Pages Ready — Preview & PDF Download Available!');

        // Background-warm remaining pages silently in parallel batches of 32
        if (total > 4) {
          (async function () {
            var BG_BATCH = 32;
            for (var i = 4; i < total; i += BG_BATCH) {
              var slice = doc.pages.slice(i, i + BG_BATCH);
              await Promise.all(slice.map(async function (p) {
                await resolveSinglePageIfNeeded(p, doc.assetPrefix);
                updateThumbnailAndGridDomForPage(p);
              }));
            }
          })();
        }
      } catch (err) {
        isBusy = false;
        setFetchLoadingState(false, CFG.fetchBtnText);
        progressPanel.style.display = 'none';
        showError(err && err.message ? err.message : 'Unable to fetch Scribd document.');
      }
    });

    // STEP 3: ULTRA-FAST PARALLEL COMPILE & DOWNLOAD ACTUAL MULTI-PAGE PDF
    downloadPdfBtn.addEventListener('click', async function () {
      if (!currentDoc || isBusy) return;

      triggerAdUrlIfConfigured(CFG.downloadBtnAdUrl);

      isBusy = true;
      var total = currentDoc.pages.length;

      var countdown = parseInt(CFG.downloadCountdownSec, 10) || 0;
      while (countdown > 0) {
        setDownloadLoadingState(true, 'Starting in ' + countdown + 's...');
        await new Promise(function (r) { setTimeout(r, 1000); });
        countdown--;
      }

      setDownloadLoadingState(true, 'Building PDF (0/' + total + ')...');
      setProgressStatus(true, 'Preparing ' + total + ' pages for PDF...');

      try {
        var jspdfNs = window.jspdf;
        if (!jspdfNs || !jspdfNs.jsPDF) {
          throw new Error('PDF compiler library is still loading. Please try again in a moment.');
        }

        var format = (CFG.pdfPageSize || 'A4').toLowerCase() === 'letter' ? 'letter' : 'a4';
        var pdf = new jspdfNs.jsPDF({ orientation: 'p', unit: 'pt', format: format });
        var pageWidth = pdf.internal.pageSize.getWidth();
        var pageHeight = pdf.internal.pageSize.getHeight();

        var dataUrls = new Array(total);
        var completed = 0;
        var IMG_BATCH = 12;

        for (var b = 0; b < total; b += IMG_BATCH) {
          var batchIndices = [];
          for (var k = b; k < Math.min(total, b + IMG_BATCH); k++) {
            batchIndices.push(k);
          }
          await Promise.all(batchIndices.map(async function (idx) {
            var p = currentDoc.pages[idx];
            if (!p.imageUrl && p.jsonpUrl) {
              await resolveSinglePageIfNeeded(p, currentDoc.assetPrefix);
            }
            if (p.imageUrl) {
              dataUrls[idx] = await fetchImageAsDataUrl(p.imageUrl);
            }
            completed++;
            var pct = Math.round((completed / total) * 100);
            progressBarFill.style.width = pct + '%';
            setDownloadLoadingState(true, 'Building PDF (' + completed + '/' + total + ')...');
            setProgressStatus(true, 'Building PDF (' + completed + ' of ' + total + ' pages)...');
          }));
        }

        for (var i = 0; i < total; i++) {
          if (i > 0) pdf.addPage(format, 'p');
          var p = currentDoc.pages[i];
          var addedImage = false;
          if (dataUrls[i]) {
            try {
              pdf.addImage(dataUrls[i], 'JPEG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
              addedImage = true;
            } catch (imgErr) {}
          }

          if (!addedImage) {
            pdf.setFontSize(11);
            var txt = p.text || ('Document #' + currentDoc.id + ' - Page ' + p.pageNumber);
            var lines = pdf.splitTextToSize(txt, pageWidth - 72);
            pdf.text(lines.slice(0, 48), 36, 48);
          }
        }

        var safeName = (currentDoc.title || ('scribd-' + currentDoc.id))
          .replace(/[^a-zA-Z0-9_-]+/g, '-')
          .replace(/^-+|-+$/g, '')
          .slice(0, 60) || ('scribd-' + currentDoc.id);

        pdf.save(safeName + '.pdf');
        setProgressStatus(false, 'PDF Downloaded Successfully (' + total + ' Pages)!');
      } catch (err) {
        showError(err && err.message ? err.message : 'Failed to build PDF.');
      } finally {
        isBusy = false;
        setDownloadLoadingState(false, CFG.downloadBtnText + ' (' + currentDoc.pages.length + ' Pages)');
      }
    });
  }

  function bootAll() {
    var wrappers = document.querySelectorAll('.sdp-wrapper');
    wrappers.forEach(function (w) {
      if (!w.getAttribute('data-sdp-initialized')) {
        w.setAttribute('data-sdp-initialized', '1');
        initWidget(w);
      }
    });
  }

  bootAll();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootAll);
  }
})();
