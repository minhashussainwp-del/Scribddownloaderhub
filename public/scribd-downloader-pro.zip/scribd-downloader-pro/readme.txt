=== Scribd Downloader Pro ===
Contributors: scribddownloader
Version: 3.0.0
Requires at least: 5.6
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later

Ultra-Fast Scribd Document Downloader & Real Multi-Page PDF Compiler for WordPress (v3.0 Turbo Engine) with Button + Banner Ads.

== Description ==

1. Upload `scribd-downloader-pro.zip` via **WordPress Admin -> Plugins -> Add New -> Upload Plugin** (replace existing if prompted).
2. Activate **Scribd Downloader Pro**.
3. Configure your Button Ads, Banner Ads, and Turbo Engine in **WP Admin -> Scribd Pro**.
4. Place the shortcode `[scribd_downloader]` on any Page or Post.
